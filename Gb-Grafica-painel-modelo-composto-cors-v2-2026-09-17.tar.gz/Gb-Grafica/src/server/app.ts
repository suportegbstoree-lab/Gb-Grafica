import { createHash, randomUUID } from 'node:crypto';
import express from 'express';
import axios from 'axios';
import cors from 'cors';
import { GoogleGenAI } from '@google/genai';
import { getAdminServices, isFirebaseAdminConfigured } from './firebaseAdmin.js';
import {
  createCartItemId,
  isValidBrazilianPhone,
  isValidCpf,
  parseMoneyToCents,
} from '../lib/commerce.js';
import {
  isAllowedArtwork,
  isOrderArtworkPath,
  isOrderPersonalizationModelPath,
  isPendingArtworkPath,
  isPendingPersonalizationModelPath,
  matchesArtworkSignature,
  sanitizeArtworkName,
} from '../lib/artwork.js';
import { isComposablePersonalizationImage } from '../lib/personalizationModel.js';
import {
  allowedFulfillmentTransitions,
  isFulfillmentStatus,
  legacyFulfillmentStatus,
  legacyStatusForFulfillment,
  type DeliveryMethod,
  type FulfillmentStatus,
  type PaymentStatus,
} from '../lib/orderStatus.js';
import {
  pagBankBuyerFeeCents,
  parsePagBankWebhookEvent,
  shouldApplyPaymentStatus,
  validatePagBankWebhookEvent,
  type PagBankWebhookEvent,
} from './pagbankWebhook.js';
import { reconcilePagBankCheckout } from './pagbankReconciliation.js';
import {
  checkoutRequestDocumentId,
  normalizeCheckoutRequestId,
  trustedPagBankPayLink,
} from './checkoutSecurity.js';
import { pagBankAuthenticityFailureReason } from './pagbankAuthenticity.js';
import type { PagBankAuthenticityFailureReason } from './pagbankAuthenticity.js';
import {
  savePagBankCheckoutEvidence,
  savePagBankWebhookEvidence,
} from './pagbankHomologation.js';
import {
  pagBankNotificationMatchesProviderEvent,
  parsePagBankNotificationForProviderLookup,
} from './pagbankWebhookFallback.js';
import { isCurrentLegalAcceptance, LEGAL_VERSIONS } from '../lib/legal.js';
import {
  activePersonalizationFonts,
  isProductCustomizationType,
  legacyTextCustomization,
  normalizeTextCustomization,
  productRequiresArtwork,
  productRequiresText,
  textCustomizationFingerprint,
  type TextCustomization,
} from '../lib/textCustomization.js';
import { promotionalPrice } from '../lib/promotions.js';
import type { Anuncio, Promocao } from '../types.js';
import {
  logEvent,
  requestObservability,
  requestRequestId,
  responseRequestId,
} from './observability.js';
import type { DocumentReference } from 'firebase-admin/firestore';

type RawBodyRequest = express.Request & { rawBody?: string };
type PlainRecord = Record<string, unknown>;

interface ShippingQuote {
  cep: string;
  amountCents: number;
  address: string;
  state: string;
  street: string;
  neighborhood: string;
  city: string;
}

interface NormalizedCartItem {
  cartItem: {
    id: string;
    productId: string;
    nome: string;
    imagem: string;
    preco: string;
    precoOriginal?: string;
    promocaoId?: string;
    descontoPercentual?: number;
    selecoes: Record<string, string>;
    quantidade: number;
    arquivoPath?: string;
    arquivoNome?: string;
    modeloPath?: string;
    modeloNome?: string;
    textoPersonalizado?: string;
    personalizacaoTexto?: TextCustomization;
  };
  checkoutItem: {
    reference_id: string;
    name: string;
    description: string;
    quantity: number;
    unit_amount: number;
    image_url?: string;
  };
  amountCents: number;
}

interface PagBankCheckoutResponse {
  id?: string;
  status?: string;
  links?: Array<{ rel?: string; href?: string }>;
}

interface StoredPaymentReconciliationResult {
  paymentStatus: unknown;
  pagbankStatus: unknown;
  reconciled: boolean;
  providerEvent: PagBankWebhookEvent | null;
}

class HttpError extends Error {
  constructor(
    public readonly status: number,
    public readonly publicMessage: string,
    public readonly code?: string,
  ) {
    super(publicMessage);
    this.name = 'HttpError';
  }
}

const rateLimitBuckets = new Map<string, { count: number; resetAt: number }>();

function enforceRateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  if (rateLimitBuckets.size > 5_000) {
    for (const [bucketKey, bucket] of rateLimitBuckets) {
      if (bucket.resetAt <= now) rateLimitBuckets.delete(bucketKey);
    }
  }
  const current = rateLimitBuckets.get(key);

  if (!current || current.resetAt <= now) {
    rateLimitBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }

  if (current.count >= limit) {
    throw new HttpError(429, 'Muitas tentativas em pouco tempo. Aguarde e tente novamente.');
  }

  current.count += 1;
}

async function enforceDistributedRateLimit(
  db: ReturnType<typeof getAdminServices>['db'],
  key: string,
  limit: number,
  windowMs: number,
) {
  const now = Date.now();
  const documentId = createHash('sha256').update(key).digest('hex');
  const rateLimitRef = db.collection('_rateLimits').doc(documentId);

  await db.runTransaction(async transaction => {
    const snapshot = await transaction.get(rateLimitRef);
    const data = snapshot.data() as PlainRecord | undefined;
    const resetAt = typeof data?.resetAt === 'number' ? data.resetAt : 0;
    const count = typeof data?.count === 'number' ? data.count : 0;

    if (!snapshot.exists || resetAt <= now) {
      transaction.set(rateLimitRef, {
        count: 1,
        resetAt: now + windowMs,
        expiresAt: new Date(now + windowMs + 24 * 60 * 60 * 1000),
      });
      return;
    }

    if (count >= limit) {
      throw new HttpError(429, 'Muitas tentativas em pouco tempo. Aguarde e tente novamente.');
    }

    transaction.update(rateLimitRef, { count: count + 1 });
  });
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(requestObservability);

app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  if (process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self' https://apis.google.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' data: https://firebasestorage.googleapis.com; connect-src 'self' https://*.googleapis.com https://*.firebaseio.com wss://*.firebaseio.com; frame-src https://accounts.google.com https://*.firebaseapp.com; upgrade-insecure-requests",
    );
  }
  next();
});

function configuredOrigins(): Set<string> {
  const candidates = [
    process.env.APP_URL,
    ...(process.env.APP_ALLOWED_ORIGINS || '').split(','),
  ];
  const origins = new Set<string>();

  for (const candidate of candidates) {
    if (!candidate?.trim()) continue;
    try {
      const parsed = new URL(candidate.trim());
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') origins.add(parsed.origin);
    } catch {
      // APP_URL is validated with a user-facing error when checkout needs it.
    }
  }

  return origins;
}

app.use(cors({
  origin: (origin, callback) => {
    const allowedOrigins = configuredOrigins();
    const isLocalDevelopmentOrigin = process.env.NODE_ENV !== 'production' && Boolean(
      origin && /^https?:\/\/(localhost|127\.0\.0\.1|terminal\.local)(:\d+)?$/.test(origin),
    );

    // Requests without an Origin include server-to-server webhooks and local tools.
    if (!origin || allowedOrigins.has(origin) || isLocalDevelopmentOrigin) {
      callback(null, true);
      return;
    }

    callback(new HttpError(403, 'Origem não autorizada.', 'ORIGIN_NOT_ALLOWED'));
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Authenticity-Token', 'X-Request-Id'],
  exposedHeaders: ['X-Request-Id'],
}));

app.use('/api', (req, res, next) => {
  if (['POST', 'PUT', 'PATCH'].includes(req.method) && !req.is(['application/json', 'application/*+json'])) {
    sendError(res, new HttpError(415, 'Envie o corpo da requisição em JSON.', 'UNSUPPORTED_MEDIA_TYPE'));
    return;
  }
  next();
});

app.use(express.json({
  limit: '256kb',
  verify: (request, _response, buffer) => {
    (request as RawBodyRequest).rawBody = buffer.toString('utf8');
  },
}));

app.use((req, res, next) => {
  if (req.path === '/api' || req.path.startsWith('/api/')) {
    res.setHeader('Cache-Control', 'no-store');
  }
  next();
});

function getPagBankConfig() {
  const environment = process.env.PAGBANK_ENV?.trim().toLowerCase() === 'production'
    ? 'production'
    : 'sandbox';

  return {
    token: process.env.PAGBANK_TOKEN?.trim() || '',
    environment,
    baseUrl: environment === 'sandbox'
      ? 'https://sandbox.api.pagseguro.com'
      : 'https://api.pagseguro.com',
  } as const;
}

function getPublicAppUrl(req: express.Request): string {
  const configuredUrl = process.env.APP_URL?.trim();

  if (configuredUrl) {
    try {
      const parsed = new URL(configuredUrl);
      if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Protocolo inválido');
      if (process.env.NODE_ENV === 'production' && parsed.protocol !== 'https:') {
        throw new Error('HTTPS obrigatório');
      }
      return parsed.origin + parsed.pathname.replace(/\/+$/, '');
    } catch {
      throw new HttpError(500, 'APP_URL está inválida no servidor.');
    }
  }

  if (process.env.NODE_ENV === 'production') {
    throw new HttpError(500, 'APP_URL não está configurada no servidor.');
  }

  const host = req.get('host');
  if (!host) throw new HttpError(500, 'Não foi possível identificar a URL da aplicação.');

  const forwardedProtocol = req.get('x-forwarded-proto')?.split(',')[0]?.trim();
  const protocol = forwardedProtocol === 'https' ? 'https' : 'http';
  return `${protocol}://${host}`;
}

function isPlainRecord(value: unknown): value is PlainRecord {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function textValue(value: unknown, maxLength: number): string {
  return typeof value === 'string'
    ? value.trim().replace(/\s+/g, ' ').slice(0, maxLength)
    : '';
}

function httpUrl(value: unknown, maxLength = 2048): string | undefined {
  if (typeof value !== 'string' || !value.trim()) return undefined;

  const candidate = value.trim().slice(0, maxLength);
  try {
    const parsed = new URL(candidate);
    if (!['http:', 'https:'].includes(parsed.protocol)) return undefined;
    return candidate;
  } catch {
    return undefined;
  }
}

function validCpf(value: unknown): string {
  const cpf = typeof value === 'string' ? value.replace(/\D/g, '') : '';
  if (!isValidCpf(cpf)) throw new HttpError(422, 'Informe um CPF válido.');
  return cpf;
}

function validPhone(value: unknown): { digits: string; area: string; number: string } {
  const digits = typeof value === 'string' ? value.replace(/\D/g, '') : '';
  if (!isValidBrazilianPhone(digits)) throw new HttpError(422, 'Informe um telefone brasileiro válido.');
  return { digits, area: digits.slice(0, 2), number: digits.slice(2) };
}

function validDeliveryNumber(value: unknown): string {
  const number = textValue(value, 20);
  if (!number || !/^[\p{L}\p{N} .\-/]+$/u.test(number)) {
    throw new HttpError(422, 'Informe o número do endereço.');
  }
  return number;
}

function validAddressField(value: unknown, label: string, maxLength: number): string {
  const field = textValue(value, maxLength);
  if (field.length < 2) throw new HttpError(422, `Informe ${label} do endereço.`);
  return field;
}

async function requireFirebaseUser(req: express.Request) {
  const authorization = req.header('authorization') || '';
  const match = authorization.match(/^Bearer\s+(.+)$/i);
  if (!match) throw new HttpError(401, 'Sua sessão expirou. Faça login novamente.');

  let auth;
  try {
    auth = getAdminServices().auth;
  } catch (error) {
    logEvent('error', 'firebase_admin_unavailable', {
      request_id: requestRequestId(req),
      error,
    });
    throw new HttpError(503, 'A autenticação do servidor ainda não está configurada.');
  }

  try {
    return await auth.verifyIdToken(match[1]);
  } catch {
    throw new HttpError(401, 'Sua sessão expirou. Faça login novamente.');
  }
}

async function requireAdminUser(req: express.Request) {
  const firebaseUser = await requireFirebaseUser(req);
  if (firebaseUser.admin === true) return firebaseUser;

  const { db } = getAdminServices();
  const userSnapshot = await db.collection('users').doc(firebaseUser.uid).get();
  if (!userSnapshot.exists || userSnapshot.data()?.role !== 'admin') {
    throw new HttpError(403, 'Acesso restrito ao administrador.');
  }

  return firebaseUser;
}

async function getShippingQuote(
  deliveryMethod: unknown,
  cepValue: unknown,
  requestId?: string,
): Promise<ShippingQuote> {
  if (deliveryMethod === 'retirada') {
    return {
      cep: '',
      amountCents: 0,
      address: '',
      state: '',
      street: '',
      neighborhood: '',
      city: '',
    };
  }

  if (deliveryMethod !== 'entrega') {
    throw new HttpError(422, 'Escolha uma forma de entrega válida.');
  }

  const cep = typeof cepValue === 'string' ? cepValue.replace(/\D/g, '') : '';
  if (cep.length !== 8) throw new HttpError(422, 'Informe um CEP válido.');

  try {
    const response = await axios.get<{
      erro?: boolean;
      logradouro?: string;
      bairro?: string;
      localidade?: string;
      uf?: string;
    }>(`https://viacep.com.br/ws/${cep}/json/`, { timeout: 5000 });

    const addressData = response.data;
    const state = addressData.uf?.trim().toUpperCase() || '';
    const city = textValue(addressData.localidade, 90);

    if (addressData.erro || !/^[A-Z]{2}$/.test(state) || !city) {
      throw new HttpError(422, 'CEP não encontrado.');
    }

    const isLowerShippingCostState = ['SP', 'RJ', 'MG', 'ES', 'PR', 'SC', 'RS'].includes(state);
    const amountCents = isLowerShippingCostState ? 1850 : 3590;
    const street = textValue(addressData.logradouro, 160);
    const neighborhood = textValue(addressData.bairro, 60);
    const address = [street, neighborhood].filter(Boolean).join(', ')
      ? `${[street, neighborhood].filter(Boolean).join(', ')} - ${city}/${state}`
      : `${city}/${state}`;

    return { cep, amountCents, address, state, street, neighborhood, city };
  } catch (error) {
    if (error instanceof HttpError) throw error;
    logEvent('error', 'viacep_request_failed', {
      request_id: requestId,
      provider: 'viacep',
      error,
    });
    throw new HttpError(502, 'Não foi possível validar o CEP agora. Tente novamente.');
  }
}

async function normalizeCart(
  itemsValue: unknown,
  services: ReturnType<typeof getAdminServices>,
  userId: string,
): Promise<{
  items: NormalizedCartItem[];
  subtotalCents: number;
}> {
  const { db, bucket } = services;
  if (!Array.isArray(itemsValue) || itemsValue.length === 0 || itemsValue.length > 50) {
    throw new HttpError(422, 'O carrinho está vazio ou possui itens demais.');
  }

  const itemInputs = itemsValue.filter(isPlainRecord);
  if (itemInputs.length !== itemsValue.length) {
    throw new HttpError(422, 'Há um item inválido no carrinho.');
  }

  const [configSnapshot, promotionsSnapshot, snapshots] = await Promise.all([
    db.collection('config').doc('main').get(),
    db.collection('promocoes').get(),
    Promise.all(itemInputs.map(async (item) => {
    const productId = textValue(item.productId, 100);
    if (!productId || !/^[A-Za-z0-9_-]+$/.test(productId)) {
      throw new HttpError(422, 'Produto inválido no carrinho.');
    }
    return { item, productId, snapshot: await db.collection('anuncios').doc(productId).get() };
    })),
  ]);
  const configuredFonts = activePersonalizationFonts(configSnapshot.data()?.fontes_personalizacao);
  const promotions = promotionsSnapshot.docs.map(snapshot => ({
    id: snapshot.id,
    ...snapshot.data(),
  } as Promocao));

  const normalizedItems: NormalizedCartItem[] = [];
  let subtotalCents = 0;

  for (let index = 0; index < snapshots.length; index += 1) {
    const { item, productId, snapshot } = snapshots[index];
    if (!snapshot.exists) throw new HttpError(422, 'Um dos produtos não está mais disponível.');

    const product = snapshot.data() as PlainRecord;
    const productName = textValue(product.nome, 100);
    if (!productName) throw new HttpError(422, 'Um dos produtos está configurado incorretamente.');

    const attributes = Array.isArray(product.atributos) ? product.atributos : [];
    const attributeNames: string[] = [];
    const normalizedAttributes = attributes.map((attribute) => {
      if (!isPlainRecord(attribute)) throw new HttpError(422, 'Um dos produtos está configurado incorretamente.');
      const name = textValue(attribute.nome, 100);
      const options = Array.isArray(attribute.opcoes)
        ? attribute.opcoes
          .filter((option): option is string => typeof option === 'string')
          .map(option => option.trim())
        : [];
      if (
        !name || options.length === 0 || options.some(option => !option) ||
        new Set(options).size !== options.length || attributeNames.includes(name)
      ) {
        throw new HttpError(422, 'Um dos produtos está configurado incorretamente.');
      }
      attributeNames.push(name);
      return { name, options };
    });

    const rawSelections = isPlainRecord(item.selecoes) ? item.selecoes : {};
    if (Object.keys(rawSelections).some(key => !attributeNames.includes(key))) {
      throw new HttpError(422, `As opções de ${productName} estão inválidas.`);
    }

    const selections: Record<string, string> = {};
    for (const attribute of normalizedAttributes) {
      const rawSelection = rawSelections[attribute.name];
      const selection = typeof rawSelection === 'string'
        ? rawSelection.trim()
        : '';
      if (!selection || !attribute.options.includes(selection)) {
        throw new HttpError(422, `Selecione todas as opções de ${productName}.`);
      }
      selections[attribute.name] = selection;
    }

    const quantity = Number(item.quantidade);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 999) {
      throw new HttpError(422, 'A quantidade de um item é inválida.');
    }

    const combinationKey = normalizedAttributes.map(attribute => selections[attribute.name]).join('|');
    const combinations = isPlainRecord(product.combinacoes) ? product.combinacoes : {};
    if (normalizedAttributes.length > 0 && !(combinationKey in combinations)) {
      throw new HttpError(422, `A combinação escolhida de ${productName} está sem preço.`);
    }
    const rawPrice = normalizedAttributes.length > 0 ? combinations[combinationKey] : product.preco_base;
    const originalUnitAmount = parseMoneyToCents(rawPrice);

    if (originalUnitAmount === null || originalUnitAmount <= 0 || originalUnitAmount > 999999900) {
      throw new HttpError(422, `O preço de ${productName} está inválido.`);
    }

    const productCategory = textValue(product.categoria, 100);
    const appliedPromotion = promotionalPrice(
      originalUnitAmount,
      { id: productId, categoria: productCategory } as Pick<Anuncio, 'id' | 'categoria'>,
      promotions,
    );
    const unitAmount = appliedPromotion?.finalCents ?? originalUnitAmount;

    const lineAmount = unitAmount * quantity;
    subtotalCents += lineAmount;
    if (subtotalCents > 8999999100) {
      throw new HttpError(422, 'O valor do pedido excede o limite permitido.');
    }

    const productImage = httpUrl(product.imagem);
    const productDescription = textValue(product.desc, 255) || productName;
    const productType = isProductCustomizationType(product.tipoInput) ? product.tipoInput : 'nenhum';
    const requiresArtwork = productRequiresArtwork(productType);
    const requiresText = productRequiresText(productType);
    const artworkPath = requiresArtwork ? textValue(item.arquivoPath, 300) : '';
    const modelPath = requiresText ? textValue(item.modeloPath, 300) : '';
    let artworkName = '';
    let modelName = '';

    if (requiresArtwork) {
      if (item.artePendente === true) {
        throw new HttpError(422, `O envio posterior de arte não está disponível para ${productName}.`);
      }
      if (!artworkPath) {
        throw new HttpError(422, `Envie a arte de ${productName} antes de adicionar o produto ao pedido.`);
      }
      if (!isPendingArtworkPath(artworkPath, userId)) {
        throw new HttpError(422, `O arquivo enviado para ${productName} é inválido.`);
      }
      try {
        const artworkFile = bucket.file(artworkPath);
        const [metadata] = await artworkFile.getMetadata();
        const size = Number(metadata.size);
        const ownerId = metadata.metadata?.ownerId;
        if (
          !isAllowedArtwork(metadata.contentType, size) || ownerId !== userId ||
          (requiresText && !isComposablePersonalizationImage(metadata.contentType, size))
        ) {
          throw new HttpError(422, `O arquivo enviado para ${productName} não é permitido.`);
        }
        const [prefix] = await artworkFile.download({ start: 0, end: 15, validation: false });
        if (!matchesArtworkSignature(String(metadata.contentType), prefix)) {
          throw new HttpError(422, `O conteúdo do arquivo enviado para ${productName} não corresponde ao formato informado.`);
        }
        artworkName = sanitizeArtworkName(
          textValue(item.arquivoNome, 120) || textValue(metadata.metadata?.originalName, 120) || 'arte',
        );
      } catch (error) {
        if (error instanceof HttpError) throw error;
        throw new HttpError(422, `Não foi possível validar a arte de ${productName}. Envie o arquivo novamente.`);
      }
    }

    let textCustomization: TextCustomization | null = null;
    if (requiresText) {
      if (configuredFonts.length === 0) {
        throw new HttpError(422, `As fontes de personalização de ${productName} ainda não foram configuradas.`);
      }
      const hasStructuredCustomization = item.personalizacaoTexto !== undefined;
      textCustomization = normalizeTextCustomization(item.personalizacaoTexto, configuredFonts);
      if (hasStructuredCustomization && !textCustomization) {
        throw new HttpError(422, `A personalização de texto de ${productName} é inválida.`);
      }
      textCustomization ||= legacyTextCustomization(item.textoPersonalizado, configuredFonts);
      if (!textCustomization) {
        throw new HttpError(422, `Informe o texto, a fonte e a posição da personalização de ${productName}.`);
      }

      if (!modelPath) {
        throw new HttpError(422, `Gere o modelo composto de ${productName} antes de concluir o pedido.`);
      }
      if (!isPendingPersonalizationModelPath(modelPath, userId) || modelPath === artworkPath) {
        throw new HttpError(422, `O modelo composto de ${productName} é inválido.`);
      }
      try {
        const modelFile = bucket.file(modelPath);
        const [metadata] = await modelFile.getMetadata();
        const size = Number(metadata.size);
        const ownerId = metadata.metadata?.ownerId;
        const kind = metadata.metadata?.kind;
        if (
          !isComposablePersonalizationImage(metadata.contentType, size) ||
          ownerId !== userId || kind !== 'personalization-model'
        ) {
          throw new HttpError(422, `O modelo composto de ${productName} não é permitido.`);
        }
        const [prefix] = await modelFile.download({ start: 0, end: 15, validation: false });
        if (!matchesArtworkSignature(String(metadata.contentType), prefix)) {
          throw new HttpError(422, `O conteúdo do modelo composto de ${productName} é inválido.`);
        }
        modelName = sanitizeArtworkName(
          textValue(item.modeloNome, 120) || textValue(metadata.metadata?.originalName, 120) || 'modelo.webp',
        );
      } catch (error) {
        if (error instanceof HttpError) throw error;
        throw new HttpError(422, `Não foi possível validar o modelo composto de ${productName}. Gere-o novamente.`);
      }
    }
    const customText = textCustomization?.texto;
    const customizationFingerprint = textCustomization ? textCustomizationFingerprint(textCustomization) : '';
    const cartId = createCartItemId(productId, selections, customizationFingerprint, artworkPath || modelPath);
    const price = (unitAmount / 100).toFixed(2);

    normalizedItems.push({
      cartItem: {
        id: cartId,
        productId,
        nome: productName,
        imagem: productImage || '',
        preco: price,
        ...(appliedPromotion ? {
          precoOriginal: (originalUnitAmount / 100).toFixed(2),
          promocaoId: appliedPromotion.promotion.id,
          descontoPercentual: appliedPromotion.percentage,
        } : {}),
        selecoes: selections,
        quantidade: quantity,
        ...(artworkPath ? { arquivoPath: artworkPath, arquivoNome: artworkName } : {}),
        ...(modelPath ? { modeloPath: modelPath, modeloNome: modelName } : {}),
        ...(textCustomization ? {
          textoPersonalizado: customText,
          personalizacaoTexto: textCustomization,
        } : {}),
      },
      checkoutItem: {
        reference_id: productId.slice(0, 64),
        name: productName,
        description: productDescription,
        quantity,
        unit_amount: unitAmount,
      },
      amountCents: lineAmount,
    });
  }

  return { items: normalizedItems, subtotalCents };
}

function providerErrorDetails(error: unknown): unknown {
  if (!axios.isAxiosError(error)) return error instanceof Error ? error.message : String(error);
  return {
    status: error.response?.status,
    data: error.response?.data,
  };
}

function normalizedCheckoutRequestId(value: unknown): string {
  const requestId = normalizeCheckoutRequestId(value);
  if (!requestId) {
    throw new HttpError(422, 'Identificador da tentativa de checkout inválido. Atualize a página e tente novamente.');
  }
  return requestId;
}

function checkoutRequestReference(
  db: ReturnType<typeof getAdminServices>['db'],
  userId: string,
  requestId: string,
) {
  const id = checkoutRequestDocumentId(userId, requestId);
  return db.collection('_checkoutRequests').doc(id);
}

function existingCheckoutResult(
  data: PlainRecord | undefined,
  environment: 'sandbox' | 'production',
): { order_id: string; checkout_id: string; init_point: string } | null {
  if (data?.status !== 'completed') return null;
  const orderId = textValue(data.orderId, 64);
  const checkoutId = textValue(data.checkoutId, 100);
  const payLink = trustedPagBankPayLink(data.payLink, environment);
  if (!orderId || !checkoutId || !payLink) return null;
  return { order_id: orderId, checkout_id: checkoutId, init_point: payLink };
}

async function copyArtworksToOrder(
  items: NormalizedCartItem[],
  services: ReturnType<typeof getAdminServices>,
  userId: string,
  orderId: string,
): Promise<{ pendingPaths: string[]; orderPaths: string[] }> {
  const pendingPaths: string[] = [];
  const orderPaths: string[] = [];

  try {
    for (const item of items) {
      const assets = [
        { field: 'arquivoPath' as const, path: item.cartItem.arquivoPath, model: false },
        { field: 'modeloPath' as const, path: item.cartItem.modeloPath, model: true },
      ];

      for (const asset of assets) {
        const sourcePath = asset.path;
        if (!sourcePath) continue;
        const isValidSource = asset.model
          ? isPendingPersonalizationModelPath(sourcePath, userId)
          : isPendingArtworkPath(sourcePath, userId);
        if (!isValidSource) {
          throw new HttpError(422, `${asset.model ? 'O modelo composto' : 'A arte'} de ${item.cartItem.nome} não está mais disponível.`);
        }

        const fileName = sourcePath.split('/').at(-1) || '';
        const destinationPath = `artworks/${userId}/orders/${orderId}/${item.cartItem.id}/${fileName}`;
        const isValidDestination = asset.model
          ? isOrderPersonalizationModelPath(destinationPath, userId, orderId)
          : isOrderArtworkPath(destinationPath, userId, orderId);
        if (!isValidDestination) {
          throw new HttpError(500, `Não foi possível preparar o destino ${asset.model ? 'do modelo' : 'da arte'}.`);
        }

        await services.bucket.file(sourcePath).copy(services.bucket.file(destinationPath));
        item.cartItem[asset.field] = destinationPath;
        pendingPaths.push(sourcePath);
        orderPaths.push(destinationPath);
      }
    }
  } catch (error) {
    const cleanupResults = await Promise.allSettled(orderPaths.map(path => services.bucket.file(path).delete()));
    if (cleanupResults.some(result => result.status === 'rejected')) {
      logEvent('error', 'checkout_partial_artwork_cleanup_failed', {
        order_id: orderId,
        copied_files: orderPaths.length,
      });
    }
    throw error;
  }

  return { pendingPaths, orderPaths };
}

function currentFulfillmentStatus(order: PlainRecord): FulfillmentStatus {
  return isFulfillmentStatus(order.fulfillmentStatus)
    ? order.fulfillmentStatus
    : legacyFulfillmentStatus(order.status, order.paymentStatus as PaymentStatus | undefined);
}

function paymentUpdateFromEvent(
  currentOrder: PlainRecord,
  event: PagBankWebhookEvent,
  eventAt: string,
): PlainRecord {
  const buyerFeeCents = pagBankBuyerFeeCents(event, currentOrder);
  const update: PlainRecord = {
    paymentStatus: event.paymentStatus,
    pagbankStatus: event.providerStatus,
    pagbankLastEventAt: eventAt,
    ...(event.providerId.startsWith('CHEC_') ? { pagbankCheckoutId: event.providerId } : {}),
    ...(event.providerId.startsWith('ORDE_') ? { pagbankOrderId: event.providerId } : {}),
    ...(event.chargeId ? { pagbankChargeId: event.chargeId } : {}),
    ...(event.paymentMethod ? { pagbankPaymentMethod: event.paymentMethod } : {}),
    ...(event.amountCents !== null ? { pagbankChargedAmountCents: event.amountCents } : {}),
    ...(buyerFeeCents !== null ? { pagbankBuyerFeeCents: buyerFeeCents } : {}),
  };

  if (event.paymentStatus === 'pago') {
    const fulfillment = currentFulfillmentStatus(currentOrder);
    update.status = 'Pago';
    if (fulfillment === 'aguardando_pagamento') {
      update.fulfillmentStatus = 'pagamento_confirmado';
    }
  }
  return update;
}

async function reconcileStoredOrderPayment(
  db: ReturnType<typeof getAdminServices>['db'],
  orderId: string,
  initialOrder: PlainRecord,
  pagbank: ReturnType<typeof getPagBankConfig>,
  options: { forceProviderLookup?: boolean } = {},
): Promise<StoredPaymentReconciliationResult> {
  const checkoutId = textValue(initialOrder.pagbankCheckoutId, 110);
  if (
    !pagbank.token ||
    !checkoutId ||
    (initialOrder.paymentStatus === 'pago' && !options.forceProviderLookup)
  ) {
    return {
      paymentStatus: initialOrder.paymentStatus || 'pendente',
      pagbankStatus: initialOrder.pagbankStatus || null,
      reconciled: false,
      providerEvent: null,
    };
  }

  const lookup = await reconcilePagBankCheckout({
    baseUrl: pagbank.baseUrl,
    token: pagbank.token,
    checkoutId,
    referenceId: orderId,
  });
  const event = lookup.event;
  const firstProviderOrderId = lookup.providerOrderIds[0];
  const orderRef = db.collection('orders').doc(orderId);

  if (!event) {
    if (firstProviderOrderId && !initialOrder.pagbankOrderId) {
      await orderRef.set({ pagbankOrderId: firstProviderOrderId }, { merge: true });
    }
    return {
      paymentStatus: initialOrder.paymentStatus || 'pendente',
      pagbankStatus: lookup.checkoutStatus || initialOrder.pagbankStatus || null,
      reconciled: false,
      providerEvent: null,
    };
  }

  const eventAt = new Date().toISOString();
  const eventHash = createHash('sha256').update([
    'provider-reconciliation',
    event.providerId,
    event.chargeId,
    event.providerStatus,
  ].join(':'), 'utf8').digest('hex');
  const eventRef = orderRef.collection('pagbankEvents').doc(eventHash);
  let paymentStatus: unknown = initialOrder.paymentStatus || 'pendente';
  let pagbankStatus: unknown = initialOrder.pagbankStatus || null;
  let reconciled = false;

  await db.runTransaction(async transaction => {
    const orderSnapshot = await transaction.get(orderRef);
    const eventSnapshot = await transaction.get(eventRef);
    if (!orderSnapshot.exists) throw new Error('Pedido desapareceu durante a reconciliação.');
    const currentOrder = orderSnapshot.data() as PlainRecord;
    paymentStatus = currentOrder.paymentStatus || 'pendente';
    pagbankStatus = currentOrder.pagbankStatus || null;

    const validationError = validatePagBankWebhookEvent(event, currentOrder);
    if (validationError) throw new Error(`Reconciliação PagBank rejeitada: ${validationError}`);
    if (eventSnapshot.exists) return;

    const applied = shouldApplyPaymentStatus(currentOrder.paymentStatus, event.paymentStatus);
    const buyerFeeCents = pagBankBuyerFeeCents(event, currentOrder);
    transaction.create(eventRef, {
      providerId: event.providerId,
      ...(event.chargeId ? { chargeId: event.chargeId } : {}),
      providerStatus: event.providerStatus,
      ...(event.paymentStatus ? { paymentStatus: event.paymentStatus } : {}),
      ...(event.amountCents !== null ? { amountCents: event.amountCents } : {}),
      ...(event.currency ? { currency: event.currency } : {}),
      ...(event.paymentMethod ? { paymentMethod: event.paymentMethod } : {}),
      ...(buyerFeeCents !== null ? { buyerFeeCents } : {}),
      kind: event.kind,
      source: 'provider_reconciliation',
      applied,
      receivedAt: eventAt,
    });

    if (!applied || !event.paymentStatus) return;
    const update = paymentUpdateFromEvent(currentOrder, event, eventAt);
    transaction.set(orderRef, update, { merge: true });
    paymentStatus = event.paymentStatus;
    pagbankStatus = event.providerStatus;
    reconciled = true;
  });

  return { paymentStatus, pagbankStatus, reconciled, providerEvent: event };
}

async function processPagBankWebhookByProviderLookup(
  req: express.Request,
  res: express.Response,
  rawBody: string,
  authenticityFailure: PagBankAuthenticityFailureReason,
  authenticityHeaderPresent: boolean,
  pagbank: ReturnType<typeof getPagBankConfig>,
  requestReceivedAt: string,
): Promise<void> {
  const parsed = parsePagBankNotificationForProviderLookup(rawBody);
  if (!parsed) {
    throw new HttpError(401, 'Notificação não autenticada.', 'WEBHOOK_NOT_AUTHENTICATED');
  }

  const { db } = getAdminServices();
  enforceRateLimit(`webhook-provider-lookup:${req.ip || 'unknown'}`, 10, 60_000);
  await enforceDistributedRateLimit(
    db,
    `webhook-provider-lookup:${parsed.event.referenceId}`,
    12,
    5 * 60_000,
  );

  const orderRef = db.collection('orders').doc(parsed.event.referenceId);
  const orderSnapshot = await orderRef.get();
  if (!orderSnapshot.exists) throw new HttpError(404, 'Pedido não encontrado.');
  const currentOrder = orderSnapshot.data() as PlainRecord;

  const result = await reconcileStoredOrderPayment(
    db,
    parsed.event.referenceId,
    currentOrder,
    pagbank,
    { forceProviderLookup: true },
  );
  if (
    !result.providerEvent ||
    !pagBankNotificationMatchesProviderEvent(parsed.event, result.providerEvent)
  ) {
    logEvent('warn', 'pagbank_webhook_provider_lookup_mismatch', {
      request_id: responseRequestId(res),
      order_id: parsed.event.referenceId,
      authenticity_failure: authenticityFailure,
      received_provider_id: parsed.event.providerId,
      received_status: parsed.event.providerStatus,
      provider_id: result.providerEvent?.providerId || null,
      provider_status: result.providerEvent?.providerStatus || null,
    });
    throw new HttpError(
      503,
      'A confirmação independente da notificação ainda não está disponível.',
      'WEBHOOK_PROVIDER_VERIFICATION_PENDING',
    );
  }

  const responseBody = {
    received: true,
    verified_by: 'provider_lookup',
    applied: result.reconciled,
  };
  const eventHash = createHash('sha256').update(rawBody, 'utf8').digest('hex');

  try {
    const captured = await savePagBankWebhookEvidence(db, {
      orderId: parsed.event.referenceId,
      eventHash,
      requestUrl: `${getPublicAppUrl(req)}/api/webhook/pagbank`,
      contentType: req.get('content-type') || 'application/json',
      requestBody: parsed.payload,
      requestReceivedAt,
      responseStatus: 200,
      responseBody,
      responseSentAt: new Date().toISOString(),
      verification: 'provider_lookup',
      authenticityHeaderPresent,
    });
    if (captured) {
      logEvent('info', 'pagbank_homologation_webhook_captured', {
        request_id: responseRequestId(res),
        order_id: parsed.event.referenceId,
        provider_id: result.providerEvent.providerId,
        provider_status: result.providerEvent.providerStatus,
        verification: 'provider_lookup',
      });
    }
  } catch (captureError) {
    logEvent('error', 'pagbank_homologation_capture_failed', {
      request_id: responseRequestId(res),
      order_id: parsed.event.referenceId,
      stage: 'webhook_provider_lookup',
      error: captureError,
    });
  }

  logEvent('info', 'pagbank_webhook_verified_by_provider_lookup', {
    request_id: responseRequestId(res),
    order_id: parsed.event.referenceId,
    provider_id: result.providerEvent.providerId,
    provider_status: result.providerEvent.providerStatus,
    authenticity_failure: authenticityFailure,
    applied: result.reconciled,
  });
  res.status(200).json(responseBody);
}

async function userIsAdmin(
  firebaseUser: Awaited<ReturnType<typeof requireFirebaseUser>>,
  db: ReturnType<typeof getAdminServices>['db'],
): Promise<boolean> {
  if (firebaseUser.admin === true) return true;
  const userSnapshot = await db.collection('users').doc(firebaseUser.uid).get();
  return userSnapshot.exists && userSnapshot.data()?.role === 'admin';
}

function publicErrorCode(status: number): string {
  const codes: Record<number, string> = {
    400: 'BAD_REQUEST',
    401: 'AUTHENTICATION_REQUIRED',
    403: 'ACCESS_DENIED',
    404: 'NOT_FOUND',
    409: 'CONFLICT',
    413: 'PAYLOAD_TOO_LARGE',
    415: 'UNSUPPORTED_MEDIA_TYPE',
    422: 'VALIDATION_ERROR',
    429: 'RATE_LIMITED',
    502: 'UPSTREAM_SERVICE_ERROR',
    503: 'SERVICE_UNAVAILABLE',
  };
  return codes[status] || (status >= 500 ? 'INTERNAL_SERVER_ERROR' : 'REQUEST_FAILED');
}

function sendError(res: express.Response, error: unknown) {
  const requestId = responseRequestId(res);
  res.setHeader('X-Request-Id', requestId);

  if (error instanceof HttpError) {
    const code = error.code || publicErrorCode(error.status);
    logEvent(error.status >= 500 ? 'error' : 'warn', 'api_request_rejected', {
      request_id: requestId,
      status_code: error.status,
      error_code: code,
      error_message: error.publicMessage,
    });
    res.status(error.status).json({ error: error.publicMessage, code, request_id: requestId });
    return;
  }

  if (axios.isAxiosError(error)) {
    const code = 'PAGBANK_REQUEST_FAILED';
    logEvent('error', 'external_service_request_failed', {
      request_id: requestId,
      provider: 'pagbank',
      error,
      provider_response: providerErrorDetails(error),
    });
    res.status(502).json({
      error: 'Não foi possível criar o checkout PagBank. Tente novamente.',
      code,
      request_id: requestId,
    });
    return;
  }

  const code = 'INTERNAL_SERVER_ERROR';
  logEvent('error', 'unhandled_api_error', { request_id: requestId, error });
  res.status(500).json({
    error: 'Erro interno ao processar a solicitação.',
    code,
    request_id: requestId,
  });
}

const healthHandler = (_req: express.Request, res: express.Response) => {
  if (process.env.NODE_ENV === 'production') {
    res.json({ status: 'ok', time: new Date().toISOString() });
    return;
  }
  const pagbank = getPagBankConfig();
  res.json({
    status: 'ok',
    time: new Date().toISOString(),
    pagbank_configured: Boolean(pagbank.token),
    pagbank_env: pagbank.environment,
    firebase_admin_configured: isFirebaseAdminConfigured(),
  });
};

app.get('/api/health', healthHandler);
app.get('/health', healthHandler);

app.post('/api/shipping-quote', async (req, res) => {
  try {
    enforceRateLimit(`shipping:${req.ip || 'unknown'}`, 20, 60_000);
    const { db } = getAdminServices();
    await enforceDistributedRateLimit(db, `shipping:${req.ip || 'unknown'}`, 40, 60_000);
    const body = isPlainRecord(req.body) ? req.body : {};
    const quote = await getShippingQuote('entrega', body.cep, responseRequestId(res));
    res.json({
      cep: quote.cep,
      address: quote.address,
      state: quote.state,
      street: quote.street,
      neighborhood: quote.neighborhood,
      city: quote.city,
      amount_cents: quote.amountCents,
    });
  } catch (error) {
    sendError(res, error);
  }
});

app.post('/api/admin/ai', async (req, res) => {
  try {
    const firebaseUser = await requireAdminUser(req);
    enforceRateLimit(`ai:${firebaseUser.uid}`, 10, 60_000);
    const { db } = getAdminServices();
    await enforceDistributedRateLimit(db, `ai:${firebaseUser.uid}`, 10, 60_000);

    const apiKey = process.env.GEMINI_API_KEY?.trim();
    if (!apiKey) throw new HttpError(503, 'A IA ainda não está configurada no servidor.');

    const body = isPlainRecord(req.body) ? req.body : {};
    const action = textValue(body.action, 40);
    const title = textValue(body.title, 200);
    const description = textValue(body.description, 1500);
    const customPrompt = textValue(body.prompt, 1000);

    let prompt = '';
    switch (action) {
      case 'generate':
        if (!title) throw new HttpError(422, 'Informe o nome do produto antes de gerar a descrição.');
        prompt = `Gere uma descrição clara e persuasiva para o produto "${title}". Foque nos benefícios e casos de uso para uma gráfica e loja de personalizados. Retorne somente a descrição, sem título ou introdução.`;
        break;
      case 'improveTitle':
        if (!title) throw new HttpError(422, 'Informe um título antes de melhorá-lo.');
        prompt = `Melhore o título de produto "${title}" para torná-lo claro, atraente e amigável para busca. Retorne somente o título, sem aspas ou explicações.`;
        break;
      case 'improveDescription':
        if (!description) throw new HttpError(422, 'Informe uma descrição antes de melhorá-la.');
        prompt = `Melhore a descrição de produto a seguir para deixá-la clara, profissional e persuasiva, sem inventar especificações: "${description}". Retorne somente a descrição.`;
        break;
      case 'custom':
        if (!title || !customPrompt) throw new HttpError(422, 'Informe o produto e o comando personalizado.');
        prompt = `Escreva uma descrição para o produto "${title}" seguindo estas orientações: "${customPrompt}". Não invente dados técnicos que não estejam nas orientações. Retorne somente a descrição.`;
        break;
      default:
        throw new HttpError(422, 'Ação de IA inválida.');
    }

    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL?.trim() || 'gemini-3-flash-preview',
      contents: prompt,
    });
    const suggestion = response.text?.trim();
    if (!suggestion) throw new HttpError(502, 'A IA não retornou uma sugestão válida.');

    res.json({ suggestion });
  } catch (error) {
    if (!(error instanceof HttpError)) {
      logEvent('error', 'gemini_request_failed', {
        request_id: responseRequestId(res),
        provider: 'gemini',
        error,
      });
    }
    sendError(res, error instanceof HttpError ? error : new HttpError(502, 'Não foi possível consultar a IA agora.'));
  }
});

const checkoutHandler = async (req: express.Request, res: express.Response) => {
  let orderRef: DocumentReference | null = null;
  let requestRef: DocumentReference | null = null;
  let ownsRequest = false;
  let orderCreated = false;
  let copiedOrderPaths: string[] = [];
  let checkoutBodyForEvidence: PlainRecord | null = null;
  let checkoutRequestSentAt = '';

  try {
    const pagbank = getPagBankConfig();
    if (!pagbank.token) throw new HttpError(503, 'O PagBank ainda não está configurado no servidor.');

    const firebaseUser = await requireFirebaseUser(req);
    const services = getAdminServices();
    const { db } = services;
    const body = isPlainRecord(req.body) ? req.body : {};
    const requestId = normalizedCheckoutRequestId(body.requestId);
    requestRef = checkoutRequestReference(db, firebaseUser.uid, requestId);

    const previousRequest = await requestRef.get();
    if (previousRequest.exists) {
      const previousData = previousRequest.data() as PlainRecord;
      const result = existingCheckoutResult(previousData, pagbank.environment);
      if (result) {
        res.status(200).json({ payment_method: 'hosted', ...result, reused: true });
        return;
      }
      throw new HttpError(
        409,
        previousData.status === 'creating'
          ? 'Este checkout já está sendo processado. Consulte seus pedidos em alguns instantes.'
          : 'Esta tentativa de checkout não pode ser repetida. Inicie uma nova tentativa.',
      );
    }

    if (!isCurrentLegalAcceptance(body.legalAcceptance)) {
      throw new HttpError(422, 'Revise e aceite os termos da compra antes de iniciar o pagamento.');
    }
    const legalAcceptance = {
      acceptedAt: new Date().toISOString(),
      termsVersion: LEGAL_VERSIONS.terms,
      privacyVersion: LEGAL_VERSIONS.privacy,
      exchangesVersion: LEGAL_VERSIONS.exchanges,
    };

    enforceRateLimit(`checkout:${firebaseUser.uid}`, 1, 3_000);
    await enforceDistributedRateLimit(db, `checkout:${firebaseUser.uid}`, 5, 5 * 60_000);

    const email = typeof firebaseUser.email === 'string' ? firebaseUser.email.trim().toLowerCase() : '';
    if (!email || email.length > 60) throw new HttpError(422, 'Sua conta não possui um e-mail compatível com o PagBank.');

    const customerName = textValue(body.customerName || firebaseUser.name, 100);
    if (customerName.length < 3 || customerName.split(' ').filter(Boolean).length < 2) {
      throw new HttpError(422, 'Informe nome e sobrenome.');
    }
    const cpf = validCpf(body.cpf);
    const phone = validPhone(body.phone);
    const deliveryMethod = body.deliveryMethod as DeliveryMethod;
    const shipping = await getShippingQuote(deliveryMethod, body.cep, responseRequestId(res));
    const deliveryAddress = deliveryMethod === 'entrega'
      ? {
          cep: shipping.cep,
          rua: validAddressField(body.addressStreet || shipping.street, 'a rua', 160),
          numero: validDeliveryNumber(body.addressNumber),
          complemento: textValue(body.addressComplement, 40),
          bairro: validAddressField(body.addressNeighborhood || shipping.neighborhood, 'o bairro', 60),
          cidade: shipping.city,
          estado: shipping.state,
        }
      : null;
    const normalizedCart = await normalizeCart(body.items, services, firebaseUser.uid);
    const totalCents = normalizedCart.subtotalCents + shipping.amountCents;

    if (totalCents <= 0 || totalCents > 8999999100) {
      throw new HttpError(422, 'O valor do pedido é inválido.');
    }

    const orderId = `GB-${randomUUID().replace(/-/g, '').slice(0, 20).toUpperCase()}`;
    const reservation = await db.runTransaction(async transaction => {
      const snapshot = await transaction.get(requestRef!);
      if (snapshot.exists) return { created: false, data: snapshot.data() as PlainRecord };
      transaction.create(requestRef!, {
        userId: firebaseUser.uid,
        orderId,
        status: 'creating',
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
        legalAcceptance,
      });
      return { created: true, data: undefined };
    });

    if (!reservation.created) {
      const result = existingCheckoutResult(reservation.data, pagbank.environment);
      if (result) {
        res.status(200).json({ payment_method: 'hosted', ...result, reused: true });
        return;
      }
      throw new HttpError(409, 'Este checkout já está sendo processado. Consulte seus pedidos em alguns instantes.');
    }
    ownsRequest = true;

    const copiedArtworks = await copyArtworksToOrder(
      normalizedCart.items,
      services,
      firebaseUser.uid,
      orderId,
    );
    const pendingArtworkPaths = copiedArtworks.pendingPaths;
    copiedOrderPaths = copiedArtworks.orderPaths;
    const publicAppUrl = getPublicAppUrl(req);
    const webhookUrl = `${publicAppUrl}/api/webhook/pagbank`;
    const returnUrl = `${publicAppUrl}/?pagbank=return&orderId=${encodeURIComponent(orderId)}`;
    const checkoutExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    if (webhookUrl.length > 100) {
      throw new HttpError(500, 'A URL pública do webhook excede o limite do PagBank.');
    }
    if (returnUrl.length > 255) {
      throw new HttpError(500, 'A URL pública de retorno excede o limite do PagBank.');
    }

    orderRef = db.collection('orders').doc(orderId);
    await orderRef.create({
      id: orderId,
      userId: firebaseUser.uid,
      data: new Date().toISOString(),
      itens: normalizedCart.items.map(item => item.cartItem),
      subtotal: (normalizedCart.subtotalCents / 100).toFixed(2),
      frete: (shipping.amountCents / 100).toFixed(2),
      total: (totalCents / 100).toFixed(2),
      totalCents,
      status: 'Pendente',
      paymentStatus: 'pendente',
      fulfillmentStatus: 'aguardando_pagamento',
      pagbankStatus: 'CREATING',
      metodoEntrega: deliveryMethod,
      metodoPagamento: 'pagbank',
      checkoutRequestId: requestId,
      checkoutExpiresAt,
      ...(deliveryAddress ? {
        cep: shipping.cep,
        enderecoCep: shipping.address,
        enderecoEntrega: deliveryAddress,
      } : {}),
      clienteNome: customerName,
      clienteEmail: email,
      clienteTelefone: phone.digits,
      legalAcceptance,
    });
    orderCreated = true;

    try {
      const checkoutBody: PlainRecord = {
        reference_id: orderId,
        expiration_date: checkoutExpiresAt,
        customer: {
          name: customerName,
          email,
          tax_id: cpf,
          ...(phone.digits.length === 11 ? {
            phone: {
              country: '+55',
              area: phone.area,
              number: phone.number,
            },
          } : {}),
        },
        customer_modifiable: true,
        items: normalizedCart.items.map(item => item.checkoutItem),
        payment_methods: [
          { type: 'CREDIT_CARD' },
          { type: 'BOLETO' },
          { type: 'PIX' },
        ],
        soft_descriptor: 'GB GRAFICA',
        redirect_url: returnUrl,
        redirect_waiting_time: 5,
        return_url: returnUrl,
        notification_urls: [webhookUrl],
        payment_notification_urls: [webhookUrl],
      };

      if (deliveryAddress) {
        checkoutBody.shipping = {
          type: 'FIXED',
          service_type: 'PAC',
          amount: shipping.amountCents,
          address_modifiable: false,
          address: {
            country: 'BRA',
            region_code: deliveryAddress.estado,
            city: deliveryAddress.cidade,
            postal_code: deliveryAddress.cep,
            street: deliveryAddress.rua,
            number: deliveryAddress.numero,
            locality: deliveryAddress.bairro,
            ...(deliveryAddress.complemento ? { complement: deliveryAddress.complemento } : {}),
          },
        };
      }

      const checkoutRequestUrl = `${pagbank.baseUrl}/checkouts`;
      checkoutBodyForEvidence = checkoutBody;
      checkoutRequestSentAt = new Date().toISOString();
      const response = await axios.post<PagBankCheckoutResponse>(
        checkoutRequestUrl,
        checkoutBody,
        {
          headers: {
            Authorization: `Bearer ${pagbank.token}`,
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'x-idempotency-key': requestId,
          },
          timeout: 15000,
        },
      );

      const checkoutId = textValue(response.data?.id, 100);
      try {
        const captured = await savePagBankCheckoutEvidence(db, {
          orderId,
          ...(checkoutId ? { checkoutId } : {}),
          requestId,
          requestUrl: checkoutRequestUrl,
          requestBody: checkoutBody,
          requestSentAt: checkoutRequestSentAt,
          responseStatus: response.status,
          responseBody: response.data,
          responseReceivedAt: new Date().toISOString(),
        });
        if (captured) {
          logEvent('info', 'pagbank_homologation_checkout_captured', {
            request_id: responseRequestId(res),
            order_id: orderId,
            checkout_id: checkoutId,
          });
        }
      } catch (captureError) {
        logEvent('error', 'pagbank_homologation_capture_failed', {
          request_id: responseRequestId(res),
          order_id: orderId,
          stage: 'checkout_response',
          error: captureError,
        });
      }
      const payLink = trustedPagBankPayLink(
        response.data?.links?.find(link => link.rel === 'PAY')?.href,
        pagbank.environment,
      );
      if (!checkoutId || !payLink) {
        throw new HttpError(502, 'O PagBank não retornou um link de pagamento válido.');
      }

      const batch = db.batch();
      batch.set(orderRef, {
        pagbankCheckoutId: checkoutId,
        pagbankStatus: response.data.status || 'ACTIVE',
        pagbankPayUrl: payLink,
      }, { merge: true });
      batch.set(requestRef, {
        status: 'completed',
        completedAt: new Date().toISOString(),
        checkoutId,
        payLink,
      }, { merge: true });
      await batch.commit();

      await Promise.allSettled(pendingArtworkPaths.map(path => services.bucket.file(path).delete()));

      res.status(201).json({
        payment_method: 'hosted',
        order_id: orderId,
        checkout_id: checkoutId,
        init_point: payLink,
      });
    } catch (error) {
      if (checkoutBodyForEvidence && checkoutRequestSentAt && axios.isAxiosError(error)) {
        try {
          const captured = await savePagBankCheckoutEvidence(db, {
            orderId,
            requestId,
            requestUrl: `${pagbank.baseUrl}/checkouts`,
            requestBody: checkoutBodyForEvidence,
            requestSentAt: checkoutRequestSentAt,
            responseStatus: error.response?.status ?? null,
            responseBody: error.response?.data ?? { error: 'O PagBank não retornou uma resposta HTTP.' },
            responseReceivedAt: new Date().toISOString(),
          });
          if (captured) {
            logEvent('warn', 'pagbank_homologation_error_captured', {
              request_id: responseRequestId(res),
              order_id: orderId,
              provider_status: error.response?.status ?? null,
            });
          }
        } catch (captureError) {
          logEvent('error', 'pagbank_homologation_capture_failed', {
            request_id: responseRequestId(res),
            order_id: orderId,
            stage: 'checkout_error',
            error: captureError,
          });
        }
      }
      await db.runTransaction(async transaction => {
        const snapshot = await transaction.get(orderRef!);
        if (!snapshot.exists || snapshot.data()?.paymentStatus === 'pago') return;
        transaction.set(orderRef!, {
          paymentStatus: 'erro',
          pagbankStatus: 'CREATION_FAILED',
        }, { merge: true });
      }).catch(updateError => {
        logEvent('error', 'checkout_failure_status_update_failed', {
          request_id: responseRequestId(res),
          error: updateError,
        });
      });
      await requestRef.set({
        status: 'failed',
        failedAt: new Date().toISOString(),
      }, { merge: true }).catch(() => undefined);
      throw error;
    }
  } catch (error) {
    if (ownsRequest && requestRef && !orderCreated) {
      if (copiedOrderPaths.length > 0) {
        try {
          const { bucket } = getAdminServices();
          const cleanupResults = await Promise.allSettled(
            copiedOrderPaths.map(path => bucket.file(path).delete()),
          );
          if (cleanupResults.some(result => result.status === 'rejected')) {
            throw new Error('Ao menos um arquivo definitivo não pôde ser removido.');
          }
        } catch (cleanupError) {
          logEvent('error', 'checkout_artwork_cleanup_failed', {
            request_id: responseRequestId(res),
            copied_files: copiedOrderPaths.length,
            error: cleanupError,
          });
        }
      }
      await requestRef.set({ status: 'failed', failedAt: new Date().toISOString() }, { merge: true }).catch(() => undefined);
    }
    sendError(res, error);
  }
};

app.post('/api/checkout', checkoutHandler);

app.get('/api/payment-status/:orderId', async (req, res) => {
  try {
    const firebaseUser = await requireFirebaseUser(req);
    const orderId = textValue(req.params.orderId, 64);
    if (!orderId || !/^[A-Za-z0-9_-]+$/.test(orderId)) throw new HttpError(400, 'Pedido inválido.');

    const { db } = getAdminServices();
    enforceRateLimit(`payment-status:${firebaseUser.uid}`, 30, 60_000);
    await enforceDistributedRateLimit(db, `payment-status:${firebaseUser.uid}`, 60, 60_000);
    const snapshot = await db.collection('orders').doc(orderId).get();
    if (!snapshot.exists) throw new HttpError(404, 'Pedido não encontrado.');

    const order = snapshot.data() as PlainRecord;
    if (order.userId !== firebaseUser.uid) throw new HttpError(403, 'Você não pode consultar este pedido.');

    let result = {
      paymentStatus: order.paymentStatus || 'pendente',
      pagbankStatus: order.pagbankStatus || null,
      reconciled: false,
    };
    try {
      result = await reconcileStoredOrderPayment(db, orderId, order, getPagBankConfig());
      if (result.reconciled) {
        logEvent('info', 'pagbank_payment_reconciled', {
          request_id: responseRequestId(res),
          order_id: orderId,
          provider_status: result.pagbankStatus,
        });
      }
    } catch (reconciliationError) {
      logEvent('warn', 'pagbank_payment_reconciliation_failed', {
        request_id: responseRequestId(res),
        order_id: orderId,
        error: reconciliationError,
      });
    }

    res.json({
      order_id: orderId,
      status: result.paymentStatus,
      pagbank_status: result.pagbankStatus,
      reconciled: result.reconciled,
    });
  } catch (error) {
    sendError(res, error);
  }
});

app.post('/api/admin/orders/:orderId/fulfillment', async (req, res) => {
  try {
    const firebaseUser = await requireAdminUser(req);
    const services = getAdminServices();
    const { db } = services;
    enforceRateLimit(`admin-order:${firebaseUser.uid}`, 20, 60_000);
    await enforceDistributedRateLimit(db, `admin-order:${firebaseUser.uid}`, 60, 60_000);

    const orderId = textValue(req.params.orderId, 64);
    const body = isPlainRecord(req.body) ? req.body : {};
    const requestedStatus = body.fulfillmentStatus;
    if (!orderId || !/^[A-Za-z0-9_-]+$/.test(orderId) || !isFulfillmentStatus(requestedStatus)) {
      throw new HttpError(422, 'Pedido ou etapa operacional inválida.');
    }

    const orderRef = db.collection('orders').doc(orderId);
    let appliedStatus: FulfillmentStatus = requestedStatus;
    await db.runTransaction(async transaction => {
      const snapshot = await transaction.get(orderRef);
      if (!snapshot.exists) throw new HttpError(404, 'Pedido não encontrado.');
      const order = snapshot.data() as PlainRecord;
      const current = currentFulfillmentStatus(order);
      const paymentStatus = order.paymentStatus as PaymentStatus | undefined;
      const deliveryMethod = order.metodoEntrega as DeliveryMethod | undefined;
      const allowed = allowedFulfillmentTransitions(current, paymentStatus, deliveryMethod);
      if (!allowed.includes(requestedStatus)) {
        throw new HttpError(
          409,
          paymentStatus !== 'pago'
            ? 'O pedido precisa estar pago antes de avançar para produção ou entrega.'
            : 'Essa mudança não respeita a sequência operacional do pedido.',
        );
      }

      appliedStatus = requestedStatus;
      transaction.set(orderRef, {
        fulfillmentStatus: requestedStatus,
        status: legacyStatusForFulfillment(requestedStatus),
        fulfillmentUpdatedAt: new Date().toISOString(),
      }, { merge: true });
      transaction.create(orderRef.collection('events').doc(randomUUID()), {
        type: 'fulfillment_status_changed',
        from: current,
        to: requestedStatus,
        actorUid: firebaseUser.uid,
        createdAt: new Date().toISOString(),
      });
    });

    res.json({ updated: true, fulfillmentStatus: appliedStatus });
  } catch (error) {
    sendError(res, error);
  }
});

app.get('/api/orders/:orderId/artwork/:itemId', async (req, res) => {
  try {
    const firebaseUser = await requireFirebaseUser(req);
    const services = getAdminServices();
    const { db, bucket } = services;
    enforceRateLimit(`artwork:${firebaseUser.uid}`, 20, 60_000);
    await enforceDistributedRateLimit(db, `artwork:${firebaseUser.uid}`, 60, 60_000);

    const orderId = textValue(req.params.orderId, 64);
    const itemId = textValue(req.params.itemId, 150);
    if (!orderId || !itemId || !/^[A-Za-z0-9_-]+$/.test(orderId) || !/^[A-Za-z0-9_-]+$/.test(itemId)) {
      throw new HttpError(400, 'Pedido ou item inválido.');
    }

    const snapshot = await db.collection('orders').doc(orderId).get();
    if (!snapshot.exists) throw new HttpError(404, 'Pedido não encontrado.');
    const order = snapshot.data() as PlainRecord;
    if (order.userId !== firebaseUser.uid && !(await userIsAdmin(firebaseUser, db))) {
      throw new HttpError(403, 'Você não pode acessar esta arte.');
    }

    const items = Array.isArray(order.itens) ? order.itens.filter(isPlainRecord) : [];
    const item = items.find(candidate => candidate.id === itemId);
    const artworkPath = item?.arquivoPath;
    if (!isOrderArtworkPath(artworkPath, String(order.userId || ''), orderId)) {
      throw new HttpError(404, 'Este item não possui uma arte armazenada.');
    }

    const file = bucket.file(artworkPath);
    const [exists] = await file.exists();
    if (!exists) throw new HttpError(404, 'O arquivo da arte não está mais disponível.');
    const [url] = await file.getSignedUrl({
      action: 'read',
      expires: Date.now() + 5 * 60_000,
      responseDisposition: 'attachment',
    });
    res.json({ url, expires_in: 300, filename: textValue(item?.arquivoNome, 120) || 'arte' });
  } catch (error) {
    sendError(res, error);
  }
});

app.get('/api/orders/:orderId/model/:itemId', async (req, res) => {
  try {
    const firebaseUser = await requireFirebaseUser(req);
    const services = getAdminServices();
    const { db, bucket } = services;
    enforceRateLimit(`personalization-model:${firebaseUser.uid}`, 20, 60_000);
    await enforceDistributedRateLimit(db, `personalization-model:${firebaseUser.uid}`, 60, 60_000);

    const orderId = textValue(req.params.orderId, 64);
    const itemId = textValue(req.params.itemId, 150);
    if (!orderId || !itemId || !/^[A-Za-z0-9_-]+$/.test(orderId) || !/^[A-Za-z0-9_-]+$/.test(itemId)) {
      throw new HttpError(400, 'Pedido ou item inválido.');
    }

    const snapshot = await db.collection('orders').doc(orderId).get();
    if (!snapshot.exists) throw new HttpError(404, 'Pedido não encontrado.');
    const order = snapshot.data() as PlainRecord;
    if (order.userId !== firebaseUser.uid && !(await userIsAdmin(firebaseUser, db))) {
      throw new HttpError(403, 'Você não pode acessar este modelo personalizado.');
    }

    const items = Array.isArray(order.itens) ? order.itens.filter(isPlainRecord) : [];
    const item = items.find(candidate => candidate.id === itemId);
    const modelPath = item?.modeloPath;
    if (!isOrderPersonalizationModelPath(modelPath, String(order.userId || ''), orderId)) {
      throw new HttpError(404, 'Este item não possui um modelo composto armazenado.');
    }

    const file = bucket.file(modelPath);
    const [exists] = await file.exists();
    if (!exists) throw new HttpError(404, 'O modelo composto não está mais disponível.');
    const [url] = await file.getSignedUrl({
      action: 'read',
      expires: Date.now() + 5 * 60_000,
      responseDisposition: 'inline',
    });
    res.json({ url, expires_in: 300, filename: textValue(item?.modeloNome, 120) || 'modelo.webp' });
  } catch (error) {
    sendError(res, error);
  }
});

app.post('/api/webhook/pagbank', async (req: express.Request, res: express.Response) => {
  try {
    enforceRateLimit(`webhook:${req.ip || 'unknown'}`, 120, 60_000);
  } catch (error) {
    sendError(res, error);
    return;
  }
  const pagbank = getPagBankConfig();
  if (!pagbank.token) {
    sendError(res, new HttpError(503, 'Webhook PagBank não configurado.', 'PAGBANK_NOT_CONFIGURED'));
    return;
  }

  const webhookRequestReceivedAt = new Date().toISOString();
  const rawBody = (req as RawBodyRequest).rawBody;
  const authenticityToken = req.get('x-authenticity-token')?.trim();
  const authenticityFailure = pagBankAuthenticityFailureReason(
    pagbank.token,
    rawBody,
    authenticityToken,
  );

  if (authenticityFailure) {
    logEvent('warn', 'pagbank_webhook_authentication_failed', {
      request_id: requestRequestId(req),
      reason: authenticityFailure,
      authenticity_header_present: Boolean(authenticityToken),
      raw_body_bytes: typeof rawBody === 'string' ? Buffer.byteLength(rawBody, 'utf8') : 0,
      ...(typeof rawBody === 'string' && rawBody
        ? { body_sha256: createHash('sha256').update(rawBody, 'utf8').digest('hex') }
        : {}),
      content_type: req.get('content-type') || null,
    });

    if (typeof rawBody !== 'string' || !rawBody) {
      sendError(res, new HttpError(401, 'Notificação não autenticada.', 'WEBHOOK_NOT_AUTHENTICATED'));
      return;
    }

    try {
      await processPagBankWebhookByProviderLookup(
        req,
        res,
        rawBody,
        authenticityFailure,
        Boolean(authenticityToken),
        pagbank,
        webhookRequestReceivedAt,
      );
    } catch (error) {
      if (error instanceof HttpError) {
        sendError(res, error);
      } else {
        logEvent('error', 'pagbank_webhook_provider_lookup_failed', {
          request_id: responseRequestId(res),
          error,
        });
        sendError(res, new HttpError(
          503,
          'Não foi possível confirmar a notificação diretamente no PagBank.',
          'WEBHOOK_PROVIDER_LOOKUP_FAILED',
        ));
      }
    }
    return;
  }

  try {
    const payload = JSON.parse(rawBody) as PlainRecord;
    const event = parsePagBankWebhookEvent(payload);
    if (!event || !/^GB-[A-Z0-9]{8,64}$/.test(event.referenceId)) {
      throw new HttpError(400, 'Notificação sem pedido válido.');
    }

    let db: ReturnType<typeof getAdminServices>['db'];
    try {
      db = getAdminServices().db;
    } catch (error) {
      logEvent('error', 'firebase_admin_unavailable_for_webhook', {
        request_id: responseRequestId(res),
        error,
      });
      sendError(res, new HttpError(503, 'Webhook temporariamente indisponível.', 'WEBHOOK_UNAVAILABLE'));
      return;
    }
    const orderRef = db.collection('orders').doc(event.referenceId);
    const eventHash = createHash('sha256').update(rawBody, 'utf8').digest('hex');
    const eventRef = orderRef.collection('pagbankEvents').doc(eventHash);
    let duplicate = false;
    let applied = false;

    await db.runTransaction(async transaction => {
      const orderSnapshot = await transaction.get(orderRef);
      const eventSnapshot = await transaction.get(eventRef);
      if (!orderSnapshot.exists) throw new HttpError(404, 'Pedido não encontrado.');
      if (eventSnapshot.exists) {
        duplicate = true;
        return;
      }

      const currentOrder = orderSnapshot.data() as PlainRecord;
      const validationError = validatePagBankWebhookEvent(event, currentOrder);
      if (validationError) {
        logEvent('warn', 'pagbank_webhook_rejected', {
          request_id: responseRequestId(res),
          order_id: event.referenceId,
          reason: validationError,
        });
        throw new HttpError(422, 'A notificação não corresponde aos dados do pedido.');
      }

      applied = shouldApplyPaymentStatus(currentOrder.paymentStatus, event.paymentStatus);
      const buyerFeeCents = pagBankBuyerFeeCents(event, currentOrder);
      transaction.create(eventRef, {
        providerId: event.providerId,
        ...(event.chargeId ? { chargeId: event.chargeId } : {}),
        providerStatus: event.providerStatus,
        ...(event.paymentStatus ? { paymentStatus: event.paymentStatus } : {}),
        ...(event.amountCents !== null ? { amountCents: event.amountCents } : {}),
        ...(event.currency ? { currency: event.currency } : {}),
        ...(event.paymentMethod ? { paymentMethod: event.paymentMethod } : {}),
        ...(buyerFeeCents !== null ? { buyerFeeCents } : {}),
        kind: event.kind,
        applied,
        receivedAt: new Date().toISOString(),
      });

      if (!applied || !event.paymentStatus) return;
      const update = paymentUpdateFromEvent(currentOrder, event, new Date().toISOString());
      transaction.set(orderRef, update, { merge: true });
    });

    const webhookResponseBody = { received: true, duplicate, applied };
    try {
      const webhookUrl = `${getPublicAppUrl(req)}/api/webhook/pagbank`;
      const captured = await savePagBankWebhookEvidence(db, {
        orderId: event.referenceId,
        eventHash,
        requestUrl: webhookUrl,
        contentType: req.get('content-type') || 'application/json',
        requestBody: payload,
        requestReceivedAt: webhookRequestReceivedAt,
        responseStatus: 200,
        responseBody: webhookResponseBody,
        responseSentAt: new Date().toISOString(),
        verification: 'signature',
        authenticityHeaderPresent: true,
      });
      if (captured) {
        logEvent('info', 'pagbank_homologation_webhook_captured', {
          request_id: responseRequestId(res),
          order_id: event.referenceId,
          provider_id: event.providerId,
          provider_status: event.providerStatus,
        });
      }
    } catch (captureError) {
      logEvent('error', 'pagbank_homologation_capture_failed', {
        request_id: responseRequestId(res),
        order_id: event.referenceId,
        stage: 'webhook',
        error: captureError,
      });
    }
    res.status(200).json(webhookResponseBody);
  } catch (error) {
    if (error instanceof SyntaxError) {
      sendError(res, new HttpError(400, 'Notificação inválida.', 'INVALID_WEBHOOK_JSON'));
      return;
    }
    if (error instanceof HttpError) {
      sendError(res, error);
      return;
    }
    logEvent('error', 'pagbank_webhook_processing_failed', {
      request_id: responseRequestId(res),
      error,
    });
    sendError(res, new HttpError(500, 'Erro ao processar notificação.', 'WEBHOOK_PROCESSING_FAILED'));
  }
});

app.use('/api', (_req, res) => {
  sendError(res, new HttpError(404, 'Rota da API não encontrada.', 'API_ROUTE_NOT_FOUND'));
});

app.use((error: unknown, _req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (res.headersSent) {
    next(error);
    return;
  }

  const parserError = error as { status?: unknown; type?: unknown };
  if (parserError.status === 413 || parserError.type === 'entity.too.large') {
    sendError(res, new HttpError(413, 'O corpo da requisição excede o limite permitido.', 'PAYLOAD_TOO_LARGE'));
    return;
  }
  if (error instanceof SyntaxError && parserError.type === 'entity.parse.failed') {
    sendError(res, new HttpError(400, 'O corpo da requisição contém JSON inválido.', 'INVALID_JSON'));
    return;
  }
  if (error instanceof HttpError) {
    sendError(res, error);
    return;
  }

  sendError(res, error);
});

export default app;
